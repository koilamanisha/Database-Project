--
-- GROUP MEMBERS: 11k-2116, 11k-2282, 11k-2181 (Section B)
--
-- SCHEMA NAME
--    Nexus Graphics School.sql
--
-- SCHEMA DESCRIPTION
--   This script creates the SQL*Plus tables of our Project (Nexus Graphics School).
--   Its a normalized schema script upto 3NF
--   To remove the tables use the "DB Project Drop.sql" script.
--   To insert tuples in this schema use 'DB Project Data File.sql'

DROP DATABASE DB;

Create database DB;
use DB;
CREATE TABLE Admin (
    SSN INTEGER CHECK(SSN > 0) NOT NULL,
    Name VARCHAR(20) NULL,
    Cell_Number VARCHAR(20) CHECK(length(Cell_Number) = 11) NULL, -- Assuming cell numbers are stored as strings
    PRIMARY KEY(SSN)
);


CREATE TABLE Instructor (
    Instructor_id INTEGER PRIMARY KEY CHECK(Instructor_id > 0),
    Email VARCHAR(50) NOT NULL,
    DateofBirth DATE NULL,
    Cell_Number VARCHAR(20) NULL,
    Expertise VARCHAR(50) NULL,
    Salary INTEGER CHECK(Salary > 0) NOT NULL
);

INSERT INTO Instructor VALUES(21, 'xyz@gmail.com', CURDATE(), '03314567890', 'Designing', 20000);
INSERT INTO Instructor VALUES(22, 'xyzrt@gmail.com', CURDATE(), '03314567771', 'DIP', 30000);
INSERT INTO Instructor VALUES(23, 'afrg@gmail.com', CURDATE(), '03314567899', 'Game Designing', 60000);
INSERT INTO Instructor VALUES(24, 'oopj@hotmail.com', CURDATE(), '03314567880', 'Logo Designing', 30000);
INSERT INTO Instructor VALUES(25, 'tyui@ymail.com', CURDATE(), '03314567811', 'Web Page Designing', 40000);


CREATE TABLE Instructor_Name (
    Instructor_id INTEGER CHECK(Instructor_id > 0) NOT NULL,
    Fname VARCHAR(20) NOT NULL,
    Lname VARCHAR(20) NULL,
    PRIMARY KEY (Instructor_id, Fname),
    CONSTRAINT Instructor_NameFK FOREIGN KEY (Instructor_id) REFERENCES Instructor(Instructor_id)
);

INSERT INTO Instructor_Name VALUES(21, 'Awais', 'Ahmed');
INSERT INTO Instructor_Name VALUES(22, 'Ali', 'Ahmed');
INSERT INTO Instructor_Name VALUES(23, 'Zohair', 'Ali');
INSERT INTO Instructor_Name VALUES(24, 'Kashan', 'Hussain');
INSERT INTO Instructor_Name VALUES(25, 'Sara', 'Ahmed');



CREATE TABLE Instructor_Address (
    Instructor_id INTEGER CHECK(Instructor_id > 0) NOT NULL,
    Address_PostalCode VARCHAR(20) NOT NULL,
    Address_City VARCHAR(20) NOT NULL,
    Address_Province VARCHAR(20) NULL,
    Address_HouseNo VARCHAR(10) NOT NULL,
    Address_StreetNo VARCHAR(20) NULL,
    PRIMARY KEY(Instructor_id, Address_PostalCode),
    CONSTRAINT Instructor_AddFK FOREIGN KEY(Instructor_id) REFERENCES Instructor(Instructor_id)
); 

INSERT INTO Instructor_Address VALUES(21, '7500', 'Karachi', 'Sindh', 'R103', '12');
INSERT INTO Instructor_Address VALUES(22, '7500', 'Karachi', 'Sindh', 'R109', '12');
INSERT INTO Instructor_Address VALUES(23, '7300', 'Lahore', 'Punjab', 'A103', '14');
INSERT INTO Instructor_Address VALUES(24, '7500', 'Karachi', 'Sindh', 'R110', '19');
INSERT INTO Instructor_Address VALUES(25, '7300', 'Lahore', 'Punjab', 'B103', '20');


CREATE TABLE Admin_hire_Instructor (
    Admin_SSN INTEGER CHECK(Admin_SSN > 0) NOT NULL,
    Instructor_id INTEGER CHECK(Instructor_id > 0) NOT NULL,
    HireDate DATE NULL,
    PRIMARY KEY(Admin_SSN, Instructor_id),
    CONSTRAINT Admin_has_Instructor_FK1 FOREIGN KEY(Admin_SSN) REFERENCES Admin(SSN),
    CONSTRAINT Admin_has_Instructor_FK2 FOREIGN KEY(Instructor_id) REFERENCES Instructor(Instructor_id)
);

INSERT INTO Admin_hire_Instructor VALUES(11, 21, CURDATE());
INSERT INTO Admin_hire_Instructor VALUES(12, 22, DATE_ADD(CURDATE(), INTERVAL 1 DAY));
INSERT INTO Admin_hire_Instructor VALUES(13, 23, DATE_ADD(CURDATE(), INTERVAL 5 DAY));
INSERT INTO Admin_hire_Instructor VALUES(14, 24, DATE_ADD(CURDATE(), INTERVAL 7 DAY));
INSERT INTO Admin_hire_Instructor VALUES(15, 25, DATE_ADD(CURDATE(), INTERVAL 10 DAY));


CREATE TABLE Student (
    Student_id INTEGER CHECK(Student_id > 0) NOT NULL,
    Admin_SSN INTEGER CHECK(Admin_SSN > 0) NOT NULL,
    Email VARCHAR(50) NULL,
    DateofBirth DATE NULL,
    PreviousEducation VARCHAR(50) NULL,
    PRIMARY KEY(Student_id),
    CONSTRAINT Student_FK1 FOREIGN KEY(Admin_SSN) REFERENCES Admin(SSN)
);

INSERT INTO Student VALUES(2114, 11, '2114@nex.edu.pk', CURDATE(), 'SSC HSC');
INSERT INTO Student VALUES(2115, 12, '2116@nex.edu.pk', DATE_ADD(CURDATE(), INTERVAL 1 DAY), 'SSC HSC');
INSERT INTO Student VALUES(2116, 13, '2115@nex.edu.pk', DATE_ADD(CURDATE(), INTERVAL 10 DAY), 'SSC HSC');
INSERT INTO Student VALUES(2117, 14, '2117@nex.edu.pk', DATE_ADD(CURDATE(), INTERVAL 20 DAY), 'SSC HSC');
INSERT INTO Student VALUES(2202, 15, '2202@nex.edu.pk', DATE_ADD(CURDATE(), INTERVAL 30 DAY), 'SSC HSC');



CREATE TABLE Student_Name (
    Student_id INTEGER CHECK(Student_id > 0) NOT NULL,
    Fname VARCHAR(20) NOT NULL,
    Lname VARCHAR(20) NULL,
    PRIMARY KEY (Student_id, Fname),
    CONSTRAINT Student_NameFK FOREIGN KEY (Student_id) REFERENCES Student(Student_id)
);

INSERT INTO Student_Name VALUES(2114, 'Sana', 'Ali');
INSERT INTO Student_Name VALUES(2115, 'Shoaib', 'Ahmed');
INSERT INTO Student_Name VALUES(2116, 'Sara', 'Khan');
INSERT INTO Student_Name VALUES(2117, 'Zohaib', 'Ahmed');
INSERT INTO Student_Name VALUES(2202, 'Zain', 'Malik');

CREATE TABLE Student_Address (
    Student_id INTEGER CHECK(Student_id > 0) NOT NULL,
    Address_PostalCode VARCHAR(20) NOT NULL,
    Address_City VARCHAR(20) NOT NULL,
    Address_Province VARCHAR(20) NULL,
    Address_HouseNo VARCHAR(10) NOT NULL,
    Address_StreetNo VARCHAR(20) NULL,
    PRIMARY KEY(Student_id, Address_PostalCode),
    CONSTRAINT Student_AddFK FOREIGN KEY (Student_id) REFERENCES Student(Student_id)
);

INSERT INTO Student_Address VALUES(2114, '7500', 'Karachi', 'Sindh', 'R101', '12');
INSERT INTO Student_Address VALUES(2115, '7500', 'Karachi', 'Sindh', 'A68', '20');
INSERT INTO Student_Address VALUES(2116, '7300', 'Lahore', 'Punjab', 'A11', '14');
INSERT INTO Student_Address VALUES(2117, '7500', 'Karachi', 'Sindh', 'C110', '16');
INSERT INTO Student_Address VALUES(2202, '7300', 'Lahore', 'Punjab', 'B100', '20');



CREATE TABLE Course (
    Course_Id VARCHAR(10) NOT NULL,
    Admin_SSN INTEGER CHECK(Admin_SSN > 0) NOT NULL,
    Student_id INTEGER CHECK(Student_id > 0) NOT NULL,
    Instructor_id INTEGER CHECK(Instructor_id > 0) NOT NULL,
    Course_Name VARCHAR(20) NOT NULL,
    Description VARCHAR(20) NULL,
    Credit_hours INTEGER CHECK(Credit_hours > 0) NOT NULL,
    PRIMARY KEY(Course_Id),
    CONSTRAINT Course_FK1 FOREIGN KEY(Instructor_id) REFERENCES Instructor(Instructor_id),
    CONSTRAINT Course_FK2 FOREIGN KEY(Student_id) REFERENCES Student(Student_id),
    CONSTRAINT Course_FK3 FOREIGN KEY(Admin_SSN) REFERENCES Admin(SSN)
);

INSERT INTO Course VALUES('CS101', 11, 2114, 21, 'Designing', 'ABC', 4);
INSERT INTO Course VALUES('CS102', 12, 2115, 22, 'DIP', 'ABC', 3);
INSERT INTO Course VALUES('GD110', 13, 2116, 23, 'Game Designing', 'ABC', 4);
INSERT INTO Course VALUES('LD101', 14, 2117, 24, 'Logo Designing', 'ABC', 3);
INSERT INTO Course VALUES('WD106', 15, 2202, 25, 'Web Page Designing', 'ABC', 3);



CREATE TABLE Assignment (
    Assignment_Id INTEGER CHECK(Assignment_Id > 0) NOT NULL,
    Course_Id VARCHAR(10) NOT NULL,
    Due_Date DATE NOT NULL,
    PRIMARY KEY(Assignment_Id),
    CONSTRAINT Assignment_FK1 FOREIGN KEY(Course_Id) REFERENCES Course(Course_Id)
);

INSERT INTO Assignment VALUES(311, 'CS101', CURDATE());
INSERT INTO Assignment VALUES(321, 'GD110', DATE_ADD(CURDATE(), INTERVAL 2 DAY));
INSERT INTO Assignment VALUES(331, 'WD106', DATE_ADD(CURDATE(), INTERVAL 5 DAY));


-- DROP TABLE Course_Material ;

-- Create the Course_Material table
CREATE TABLE Course_Material (
    Topics VARCHAR(20) NOT NULL,
    Course_Id VARCHAR(10) NOT NULL,
    Instructor_id INTEGER CHECK(Instructor_id > 0) NOT NULL,
    Duration VARCHAR(20) NOT NULL,
    PRIMARY KEY(Course_Id),
    CONSTRAINT Course_Material_FK1 FOREIGN KEY(Instructor_id) REFERENCES Instructor(Instructor_id),
    CONSTRAINT Course_Material_FK2 FOREIGN KEY(Course_Id) REFERENCES Course(Course_Id)
);

-- Insert data into the Course_Material table
INSERT INTO Course_Material (Topics, Course_Id, Instructor_id, Duration)
VALUES ('ABC XYZ', 'CS101', 21, '6 Months');

INSERT INTO Course_Material (Topics, Course_Id, Instructor_id, Duration)
VALUES ('ABC XYZ', 'GD110', 23, '4.5 Months');

INSERT INTO Course_Material (Topics, Course_Id, Instructor_id, Duration)
VALUES ('ABC XYZ', 'LD101', 25, '6 Months'); 



-- DROP TABLE PreRequisite;
-- Create the PreRequisite table
CREATE TABLE PreRequisite (
    PreRequisite_Id VARCHAR(10) PRIMARY KEY NOT NULL,
    Course_Id VARCHAR(10) NOT NULL,
    PreRequisite_Name VARCHAR(40) NOT NULL,
    Credit_hours INTEGER CHECK(Credit_hours > 0) NOT NULL,
    FOREIGN KEY (Course_Id) REFERENCES Course(Course_Id) ON DELETE RESTRICT
);

-- Insert data into the PreRequisite table
INSERT INTO PreRequisite (PreRequisite_Id, Course_Id, PreRequisite_Name, Credit_hours)
VALUES
  ('CS100', 'CS101', 'Initial Designing', 4),
  ('CS101', 'CS102', 'Designing', 4),
  ('WD105', 'WD106', 'Web Programming', 3),
  ('LD100', 'LD101', 'Logo and Character Sketching', 3),
  ('IE105', 'GD110', 'Image Editing', 3);
SELECT * FROM Course WHERE Course_Id IN ('CS101', 'CS102', 'WD106', 'LD101', 'GD110');

-- Create the Student_Previous_Courses table
CREATE TABLE Student_Previous_Courses (
    Previous_Courses_id VARCHAR(20) NOT NULL,
    Student_id INTEGER CHECK(Student_id > 0) NOT NULL,
    PrevCourses_Name VARCHAR(20) NOT NULL,
    Credit_hours INTEGER CHECK(Credit_hours > 0) NOT NULL,
    Grade CHAR NULL,
    PRIMARY KEY(Previous_Courses_id, Student_id),
    CONSTRAINT Std_Prev_Courses_FK1 FOREIGN KEY(Student_id) REFERENCES Student(Student_id)
);

-- Insert data into the Student_Previous_Courses table
INSERT INTO Student_Previous_Courses VALUES('CS100', 2114, 'Initial Designing', 4, 'A');
INSERT INTO Student_Previous_Courses VALUES('CS100', 2115, 'Initial Designing', 4, 'A');
INSERT INTO Student_Previous_Courses VALUES('CS101', 2115, 'Designing', 4, 'B');
INSERT INTO Student_Previous_Courses VALUES('CS100', 2116, 'Initial Designing', 4, 'B');
INSERT INTO Student_Previous_Courses VALUES('CS101', 2116, 'Designing', 4, 'C');
INSERT INTO Student_Previous_Courses VALUES('CS102', 2116, 'DIP', 3, 'A');
INSERT INTO Student_Previous_Courses VALUES('CS100', 2117, 'Initial Designing', 4, 'A');
INSERT INTO Student_Previous_Courses VALUES('CS101', 2117, 'Designing', 4, 'A');
INSERT INTO Student_Previous_Courses VALUES('CS102', 2117, 'DIP', 3, 'B');
INSERT INTO Student_Previous_Courses VALUES('LD101', 2117, 'Logo and Character Sketching', 3, 'A');

-- Create the Project table
CREATE TABLE Project (
    Project_id INTEGER CHECK(Project_id > 0) NOT NULL,
    Instructor_id INTEGER CHECK(Instructor_id > 0) NOT NULL,
    Subject VARCHAR(40) NULL,
    Format VARCHAR(10) NULL,
    PRIMARY KEY(Project_id),
    CONSTRAINT Project_FK1 FOREIGN KEY(Instructor_id) REFERENCES Instructor(Instructor_id)
);

-- Insert data into the Project table
INSERT INTO Project VALUES(1, 21, 'XYZ', 'ABC');
INSERT INTO Project VALUES(2, 22, 'KHG', 'KLP');
INSERT INTO Project VALUES(3, 23, 'JIO', 'JIP');
INSERT INTO Project VALUES(4, 24, 'ASD', 'DSA');
INSERT INTO Project VALUES(5, 25, 'VBN', 'NBV');


use DB;

-- Create the Student_Submits_Project table
-- Create the Student_Submits_Project table
CREATE TABLE Student_Submits_Project (
    Student_id INTEGER CHECK(Student_id > 0) NOT NULL,
    Project_id INTEGER CHECK(Project_id > 0) NOT NULL,
    Submission_Date DATE NOT NULL,
    PRIMARY KEY(Student_id, Project_id),
    CONSTRAINT Student_has_Project_FK1 FOREIGN KEY(Student_id) REFERENCES Student(Student_id),
    CONSTRAINT Student_has_Project_FK2 FOREIGN KEY(Project_id) REFERENCES Project(Project_id)
);
SELECT * FROM Student WHERE Student_id IN (2114, 2115, 2116, 2117, 2202);

-- Insert data into the Student_Submits_Project table
INSERT INTO Student_Submits_Project VALUES(2114, 1, NOW());
INSERT INTO Student_Submits_Project VALUES(2115, 2, NOW() + INTERVAL 2 DAY);
INSERT INTO Student_Submits_Project VALUES(2115, 3, NOW() + INTERVAL 3 DAY);
INSERT INTO Student_Submits_Project VALUES(2116, 1, NOW());
INSERT INTO Student_Submits_Project VALUES(2116, 3, NOW() + INTERVAL 3 DAY);
INSERT INTO Student_Submits_Project VALUES(2116, 4, NOW() + INTERVAL 4 DAY);
INSERT INTO Student_Submits_Project VALUES(2117, 1, NOW());
INSERT INTO Student_Submits_Project VALUES(2117, 2, NOW() + INTERVAL 2 DAY);
INSERT INTO Student_Submits_Project VALUES(2117, 5, NOW() + INTERVAL 5 DAY);
INSERT INTO Student_Submits_Project VALUES(2202, 1, NOW());
 
 INSERT INTO Project VALUES(6, 25, 'VBN', 'NBV');
  INSERT INTO Project VALUES(7, 25, 'VBN', 'NBV');
 
UPDATE Student SET Email = 'updated_email@example.com' WHERE Student_id = 1001;
UPDATE Course SET Description = 'Advanced concepts of programming' WHERE Course_Id = 'CS101';


DELETE FROM Student WHERE Student_id = 1001;

SELECT * FROM Instructor WHERE Expertise = 'Designing';

SELECT A.Name AS Admin_Name, I.Email AS Instructor_Email
FROM Admin A
INNER JOIN Instructor I ON A.Cell_Number = I.Cell_Number;

SELECT I.Email AS Instructor_Email, A.Name AS Admin_Name
FROM Instructor I
LEFT JOIN Admin A ON A.Cell_Number = I.Cell_Number;


SELECT COUNT(*) AS Total_Students, AVG(Credit_hours) AS Avg_Credit_hours FROM Course;
SELECT COUNT(*) AS Total_Courses, MAX(Salary) AS Max_Salary FROM Instructor;


SELECT A.Name AS Admin_Name, I.Email AS Instructor_Email, S.Email AS Student_Email
FROM Admin A
JOIN Instructor I ON A.Cell_Number = I.Cell_Number
JOIN Student S ON A.SSN = S.Admin_SSN;

SELECT A.Name AS Admin_Name, I.Email AS Instructor_Email
FROM Admin A
INNER JOIN Instructor I ON A.Cell_Number = I.Cell_Number;

SELECT 
    (SELECT COUNT(*) FROM Admin) AS Total_Admins,
    (SELECT COUNT(*) FROM Instructor) AS Total_Instructors;



-- Index for Instructor_Name table
CREATE INDEX idx_Instructor_Name_Instructor_id ON Instructor_Name (Instructor_id);

-- Index for Instructor_Address table
CREATE INDEX idx_Instructor_Address_Instructor_id ON Instructor_Address (Instructor_id);
CREATE INDEX idx_Instructor_Address_Address_PostalCode ON Instructor_Address (Address_PostalCode);

-- Indexes for Admin_hire_Instructor table
CREATE INDEX idx_Admin_hire_Instructor_Admin_SSN ON Admin_hire_Instructor (Admin_SSN);
CREATE INDEX idx_Admin_hire_Instructor_Instructor_id ON Admin_hire_Instructor (Instructor_id);

CREATE VIEW Instructor_Details AS
SELECT i.Instructor_id, i.Email, i.DateofBirth, i.Cell_Number,
       ia.Address_PostalCode, ia.Address_City, ia.Address_Province, ia.Address_HouseNo, ia.Address_StreetNo
FROM Instructor i
JOIN Instructor_Address ia ON i.Instructor_id = ia.Instructor_id;


CREATE VIEW Admin_Hired_Instructor_Details AS
SELECT a.Name AS Admin_Name, a.Cell_Number AS Admin_Cell_Number,
       i.Instructor_id, i.Email, i.DateofBirth, i.Cell_Number AS Instructor_Cell_Number
FROM Admin a
JOIN Admin_hire_Instructor ah ON a.SSN = ah.Admin_SSN
JOIN Instructor i ON ah.Instructor_id = i.Instructor_id;



DELIMITER //
CREATE PROCEDURE CalculateAverageSalary()
BEGIN
    DECLARE avg_salary DECIMAL(10, 2);
    
    SELECT AVG(Salary) INTO avg_salary FROM Instructor;
    
    SELECT avg_salary AS AverageSalary;
END //
DELIMITER ;

CALL CalculateAverageSalary();



-- Create Products table
CREATE TABLE Products (
    ProductID INT AUTO_INCREMENT PRIMARY KEY,
    ProductName VARCHAR(50) NOT NULL,
    Quantity INT NOT NULL
);

-- Create Orders table
CREATE TABLE Orders (
    OrderID INT AUTO_INCREMENT PRIMARY KEY,
    ProductID INT NOT NULL,
    Quantity INT NOT NULL,
    OrderDate DATE NOT NULL,
    FOREIGN KEY (ProductID) REFERENCES Products(ProductID)
);

-- Insert sample data into Products table
INSERT INTO Products (ProductName, Quantity) VALUES
('Product A', 50),
('Product B', 100),
('Product C', 75);

START TRANSACTION;

-- Update the quantity of Product A
UPDATE Products SET Quantity = Quantity - 10 WHERE ProductName = 'Product A';

-- Insert a new order for Product A
INSERT INTO Orders (ProductID, Quantity, OrderDate) 
VALUES ((SELECT ProductID FROM Products WHERE ProductName = 'Product A'), 10, CURDATE());

COMMIT;


CREATE TABLE products2 (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    stock_quantity INT NOT NULL
);

INSERT INTO products2 (name, price, stock_quantity) VALUES
('T-shirt', 20.99, 100),
('Jeans', 39.99, 50),
('Sneakers', 49.99, 75);

DELIMITER //

CREATE PROCEDURE GetInstructorNameByID (IN instructorID INT, OUT fullName VARCHAR(50))
BEGIN
    SELECT CONCAT(Fname, ' ', Lname) INTO fullName
    FROM Instructor_Name
    WHERE Instructor_id = instructorID;
END //

DELIMITER ;
CALL GetInstructorNameByID(21, @fullName);
SELECT @fullName;

DELIMITER //

CREATE TRIGGER InsertDefaultAddress
AFTER INSERT ON Instructor
FOR EACH ROW
BEGIN
    INSERT INTO Instructor_Address (Instructor_id, Address_PostalCode, Address_City, Address_HouseNo)
    VALUES (NEW.Instructor_id, '00000', 'Unknown', '0');
END //

DELIMITER ;

LOCK TABLES Instructor WRITE;
UNLOCK TABLES;

